﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AsyncExercise.Models
{
    public class ContentInfo
    {
        public double ContentLength { get; set; }
    }

}
